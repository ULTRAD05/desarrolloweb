function registrarCita() {
    alert('Cita registrada con éxito');
}
